# __init__.py
from .main import vid2aud

# Version of the package
__version__ = "0.1.0"